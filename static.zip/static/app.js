/* Inventario Negozio - interfaccia (JavaScript semplice, nessuna libreria esterna) */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const EUR = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const fmt = (v) => (v == null || v === "" || isNaN(v) ? "—" : EUR.format(v));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const MESI = ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
const dataIt = (iso, anno = true) => {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return anno ? `${d}/${m}/${y.slice(2)}` : `${+d} ${MESI[+m - 1]}`;
};
const oggiIso = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const num = (v) => {
  const n = parseFloat(String(v ?? "").replace(",", "."));
  return isFinite(n) ? n : null;
};
const plurale = (n, uno, molti) => `${n} ${n === 1 ? uno : molti}`;

const CATEGORIE = {
  pesce: ["🐟", "Pesce"], crostacei: ["🦐", "Crostacei e molluschi"], carne: ["🥩", "Carne"],
  verdure: ["🥦", "Verdure"], pronti: ["🍝", "Piatti pronti"], pizza: ["🍕", "Pane e pizza"],
  gelati: ["🍨", "Gelati e dolci"], latticini: ["🧀", "Latticini"], dispensa: ["🥫", "Dispensa"],
  altro: ["📦", "Altro"],
};
const cat = (k) => CATEGORIE[k] || CATEGORIE.altro;
const opzioniCategoria = (sel) => Object.entries(CATEGORIE)
  .map(([k, [e, n]]) => `<option value="${k}" ${k === sel ? "selected" : ""}>${e} ${n}</option>`).join("");

const state = {
  prodotti: [], documenti: [], ricarico: 40, arrotonda: "0.01", aiPronta: true,
  vista: "oggi", q: "", categoria: "", filtro: "", ord: "recenti",
  pagine: [], rev: null,
};

/* Anteprima del prezzo al pubblico (il server lo ricalcola comunque con Decimal) */
function vendita(acq) {
  const passo = parseFloat(state.arrotonda) || 0.01;
  const v = acq * (1 + state.ricarico / 100);
  return Math.round(Math.round(v / passo + 1e-7) * passo * 100) / 100;
}

/* ------------------------------------------------------------------ pezzi di interfaccia */
function cartellino(prezzo, unita) {
  if (prezzo == null) return "";
  const [i, d] = prezzo.toFixed(2).split(".");
  return `<span class="tag"><span class="i">${i}</span><span class="d">,${d}</span><span class="u">€/${unita}</span></span>`;
}
function prezzoGrande(prezzo) {
  const [i, d] = prezzo.toFixed(2).split(".");
  return `<span class="i">${i}</span><span class="d">,${d}</span>`;
}
function pill(v, nuovo = false) {
  if (nuovo) return '<span class="pill new">nuovo</span>';
  if (v == null || Math.abs(v) < 0.005) return '<span class="pill eq">invariato</span>';
  return `<span class="pill ${v > 0 ? "up" : "down"}">${v > 0 ? "+" : "−"}${EUR.format(Math.abs(v))}</span>`;
}
function delta(p) {
  if (p.n_acquisti <= 1) return '<span class="delta new">nuovo</span>';
  const v = p.variazione_ultima;
  if (Math.abs(v) < 0.005) return "";
  return `<span class="delta ${v > 0 ? "up" : "down"}">${v > 0 ? "▲ +" : "▼ −"}${EUR.format(Math.abs(v))}</span>`;
}
function sparkline(storia) {
  if (!storia || storia.length < 2) return '<svg class="spark" viewBox="0 0 52 26"></svg>';
  const lo = Math.min(...storia), hi = Math.max(...storia), span = hi - lo || 1;
  const pts = storia.map((v, i) => [2 + (i * 48) / (storia.length - 1), 22 - ((v - lo) / span) * 18]);
  const colore = storia.at(-1) > storia.at(-2) + 0.004 ? "var(--up)" : storia.at(-1) < storia.at(-2) - 0.004 ? "var(--down)" : "var(--muted)";
  const [lx, ly] = pts.at(-1);
  return `<svg class="spark" viewBox="0 0 52 26" aria-hidden="true"><polyline points="${pts.map((p) => p.map((n) => n.toFixed(1)).join(",")).join(" ")}" fill="none" stroke="${colore}"/><circle cx="${lx}" cy="${ly}" r="2.6" fill="${colore}" stroke="none"/></svg>`;
}
function rigaProdotto(p) {
  return `<button class="row" data-prodotto="${p.id}">
    <span class="avatar">${cat(p.categoria)[0]}</span>
    <span class="row-main">
      <span class="row-name">${esc(p.nome)}</span>
      <span class="row-sub num">costo ${fmt(p.prezzo_acquisto_ivato)} ${delta(p)}</span>
    </span>
    ${sparkline(p.storia)}
    ${cartellino(p.prezzo_vendita, p.unita)}
  </button>`;
}

/* ------------------------------------------------------------------ rete */
async function api(path, opts = {}) {
  const headers = opts.body && !(opts.body instanceof FormData) ? { "Content-Type": "application/json" } : {};
  let r;
  try {
    r = await fetch(path, { credentials: "same-origin", ...opts, headers });
  } catch {
    throw new Error("Il PC del negozio non risponde. Controlla che l'app sia avviata e il Wi‑Fi collegato.");
  }
  const json = (r.headers.get("content-type") || "").includes("json") ? await r.json() : null;
  if (r.status === 401 && path !== "/api/login") {
    mostraLogin();
    throw new Error("Serve il PIN");
  }
  if (!r.ok) {
    const det = json && json.detail;
    throw new Error(typeof det === "string" ? det : det ? "Controlla i campi: qualche valore non è valido." : `Errore ${r.status}`);
  }
  return json;
}

let toastTimer;
function toast(msg, tipo = "ok", ms = 3200) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = `toast ${tipo}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), ms);
}

/* ------------------------------------------------------------------ avvio e accesso */
async function avvio() {
  try {
    const s = await api("/api/stato");
    $("#nome-negozio").textContent = s.nome_negozio;
    $("#login-nome").textContent = s.nome_negozio;
    document.title = s.nome_negozio;
    if (s.pin_richiesto && !s.autenticato) return mostraLogin();
    await mostraApp();
  } catch (e) {
    toast(e.message, "ko", 9000);
  }
}
function mostraLogin() {
  $("#app").hidden = true;
  $("#login").hidden = false;
  setTimeout(() => $("#login-pin").focus(), 50);
}
$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await api("/api/login", { method: "POST", body: JSON.stringify({ pin: $("#login-pin").value }) });
    $("#login-err").hidden = true;
    await mostraApp();
  } catch {
    $("#login-err").hidden = false;
    $("#login-pin").value = "";
  }
});
async function mostraApp() {
  $("#login").hidden = true;
  $("#app").hidden = false;
  const d = new Date();
  $("#oggi-data").textContent = d.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long" });
  await ricarica();
  const sulPc = ["localhost", "127.0.0.1"].includes(location.hostname);
  let chiuso = false;
  try { chiuso = localStorage.getItem("banner-chiuso") === "1"; } catch {}
  if (sulPc && !chiuso) {
    try {
      $("#url-telefono").textContent = (await api("/api/impostazioni")).url_telefono;
      $("#banner-telefono").hidden = false;
    } catch {}
  }
}
$("#chiudi-banner").addEventListener("click", () => {
  $("#banner-telefono").hidden = true;
  try { localStorage.setItem("banner-chiuso", "1"); } catch {}
});

async function ricarica() {
  const [r, docs] = await Promise.all([api("/api/prodotti"), api("/api/documenti")]);
  Object.assign(state, { prodotti: r.prodotti, ricarico: r.ricarico, arrotonda: r.arrotonda, aiPronta: r.ai_pronta, documenti: docs });
  render();
}

/* ------------------------------------------------------------------ navigazione */
function vai(vista) {
  state.vista = vista;
  $$(".view").forEach((v) => (v.hidden = v.id !== `v-${vista}`));
  $$(".nav [data-vai]").forEach((b) => b.classList.toggle("on", b.dataset.vai === vista));
  window.scrollTo(0, 0);
  if (vista === "altro") renderAltro();
}
document.addEventListener("click", (e) => {
  const v = e.target.closest("[data-vai]");
  if (v) return vai(v.dataset.vai);
  const p = e.target.closest("[data-prodotto]");
  if (p) return apriDettaglio(state.prodotti.find((x) => x.id == p.dataset.prodotto));
  const d = e.target.closest("[data-documento]");
  if (d) return apriDocumento(state.documenti.find((x) => x.id == d.dataset.documento));
  if (e.target.closest("[data-nuova]")) return apriNuova();
  if (e.target.closest("[data-chiudi]")) return chiudiSheet();
});

function render() {
  renderOggi();
  renderProdotti();
  renderFatture();
}

/* ------------------------------------------------------------------ OGGI */
function renderOggi() {
  $("#avviso-ai").hidden = state.aiPronta;
  const daFare = state.prodotti.filter((p) => p.cartellino);
  $("#n-cartellini").textContent = daFare.length || "";
  $("#tutti-fatti").hidden = daFare.length < 2;
  $("#dot-oggi").hidden = !daFare.length;
  const box = $("#cartellini");
  if (!state.prodotti.length) {
    box.innerHTML = `<div class="calm"><b>Inizia dalla prima fattura</b><p>Fotografa una fattura o una bolla: l'app legge i prodotti, calcola il costo al pezzo o al chilo e prepara il prezzo al pubblico.</p><button class="btn btn-primary" data-nuova style="margin-top:14px">Fotografa una fattura</button></div>`;
  } else if (!daFare.length) {
    box.innerHTML = `<div class="calm"><b>Cartellini a posto</b><p>I prezzi esposti corrispondono agli ultimi acquisti.</p></div>`;
  } else {
    box.innerHTML = daFare.map((p) => `
      <button class="shelf" data-fatto="${p.id}" aria-label="${esc(p.nome)}: segna il cartellino come riscritto">
        <span class="shelf-check"><svg viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg></span>
        <div class="shelf-name">${esc(p.nome)}</div>
        <div class="shelf-price">${prezzoGrande(p.prezzo_vendita)}</div>
        <div class="shelf-foot"><span>€ al ${p.unita}</span>${p.vendita_esposta != null ? `<s>${fmt(p.vendita_esposta)}</s>` : "<span>nuovo</span>"}</div>
      </button>`).join("");
  }
  const mov = state.prodotti.slice(0, 6);
  $("#movimenti").innerHTML = mov.map(rigaProdotto).join("");
  $("#movimenti").hidden = !mov.length;
  $("#movimenti").previousElementSibling.hidden = !mov.length;
}
$("#cartellini").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-fatto]");
  if (!b || b.classList.contains("gone")) return;
  b.classList.add("gone");
  try {
    await api("/api/cartellini/fatti", { method: "POST", body: JSON.stringify({ ids: [+b.dataset.fatto] }) });
    setTimeout(ricarica, 220);
  } catch (err) {
    b.classList.remove("gone");
    toast(err.message, "ko");
  }
});
$("#tutti-fatti").addEventListener("click", async () => {
  await api("/api/cartellini/fatti", { method: "POST", body: JSON.stringify({ ids: null }) });
  toast("Cartellini segnati come riscritti");
  ricarica();
});

/* ------------------------------------------------------------------ PRODOTTI */
function renderProdotti() {
  const tutti = state.prodotti;
  const su = tutti.filter((p) => p.n_acquisti > 1 && p.variazione_ultima > 0.005).length;
  const giu = tutti.filter((p) => p.n_acquisti > 1 && p.variazione_ultima < -0.005).length;
  $("#prodotti-info").textContent = tutti.length
    ? `${plurale(tutti.length, "prodotto", "prodotti")}, ricarico del ${String(state.ricarico).replace(".", ",")}%`
    : "Ancora nessun prodotto";

  const presenti = Object.keys(CATEGORIE).filter((k) => tutti.some((p) => p.categoria === k));
  const chip = (attivo, attr, testo) => `<button class="chip ${attivo ? "on" : ""}" ${attr}>${testo}</button>`;
  $("#chips").innerHTML =
    chip(state.ord === "az", 'data-ord="az"', "A–Z") +
    (su ? chip(state.filtro === "su", 'data-filtro="su"', `▲ Rincari ${su}`) : "") +
    (giu ? chip(state.filtro === "giu", 'data-filtro="giu"', `▼ Ribassi ${giu}`) : "") +
    (presenti.length > 1 ? '<span class="chip-sep"></span>' + presenti.map((k) => chip(state.categoria === k, `data-cat="${k}"`, `${cat(k)[0]} ${cat(k)[1]}`)).join("") : "");
  $("#chips").hidden = !tutti.length;
  $(".search").hidden = !tutti.length;

  const q = state.q.trim().toLowerCase();
  let lista = tutti.filter((p) => p.nome.toLowerCase().includes(q) && (!state.categoria || p.categoria === state.categoria));
  if (state.filtro === "su") lista = lista.filter((p) => p.n_acquisti > 1 && p.variazione_ultima > 0.005);
  if (state.filtro === "giu") lista = lista.filter((p) => p.n_acquisti > 1 && p.variazione_ultima < -0.005);
  if (state.ord === "az") lista = [...lista].sort((a, b) => a.nome.localeCompare(b.nome, "it"));

  $("#lista").innerHTML = !tutti.length
    ? `<div class="empty"><b>Qui compariranno i tuoi prodotti</b><p>Si aggiungono da soli quando salvi una fattura.</p><button class="btn btn-primary" data-nuova>Fotografa una fattura</button></div>`
    : lista.length ? lista.map(rigaProdotto).join("")
    : `<div class="empty"><b>Nessun prodotto trovato</b><p>Prova con un altro nome o togli i filtri.</p></div>`;
}
$("#cerca").addEventListener("input", (e) => { state.q = e.target.value; renderProdotti(); });
$("#chips").addEventListener("click", (e) => {
  const c = e.target.closest(".chip");
  if (!c) return;
  if (c.dataset.ord) state.ord = state.ord === "az" ? "recenti" : "az";
  if (c.dataset.filtro) state.filtro = state.filtro === c.dataset.filtro ? "" : c.dataset.filtro;
  if (c.dataset.cat) state.categoria = state.categoria === c.dataset.cat ? "" : c.dataset.cat;
  renderProdotti();
});

/* ------------------------------------------------------------------ FATTURE */
function renderFatture() {
  const docs = state.documenti;
  $("#fatture-info").textContent = docs.length ? `${plurale(docs.length, "fattura salvata", "fatture salvate")}` : "Ancora nessuna fattura";
  $("#documenti").innerHTML = docs.length ? docs.map((d) => {
    const [, m, g] = d.data.split("-");
    return `<button class="doc" data-documento="${d.id}">
      <span class="doc-date"><b>${+g}</b><span>${MESI[+m - 1]}</span></span>
      <span class="doc-main"><b>${esc(d.fornitore || "Fornitore non indicato")}</b>
        <p>${plurale(d.n_righe, "prodotto", "prodotti")}${d.numero ? `, n. ${esc(d.numero)}` : ""}</p></span>
      <span class="doc-side">${d.rincari ? `<span class="pill up">▲ ${d.rincari}</span>` : ""}${d.ribassi ? `<span class="pill down">▼ ${d.ribassi}</span>` : ""}</span>
    </button>`;
  }).join("") : `<div class="panel empty"><b>L'archivio è vuoto</b><p>Ogni fattura salvata resta qui: puoi rivederla o annullarla se è stata caricata per errore.</p><button class="btn btn-primary" data-nuova>Fotografa una fattura</button></div>`;
}

async function apriDocumento(d) {
  if (!d) return;
  apriSheet(`
    <div class="sheet-head">
      <div><h3>${esc(d.fornitore || "Fattura")}</h3><p>${dataIt(d.data)}${d.numero ? `, n. ${esc(d.numero)}` : ""}</p></div>
      ${bottoneChiudi}
    </div>
    <div class="panel list" id="doc-righe"><div class="empty"><p>Carico i prodotti…</p></div></div>
    <button class="btn btn-danger btn-block" id="doc-elimina" style="margin-top:16px">Annulla questa fattura</button>
    <p class="hint" style="margin-top:10px">Annullandola, i prodotti tornano al prezzo della fornitura precedente.</p>`);
  const righe = await api(`/api/documenti/${d.id}`);
  $("#doc-righe").innerHTML = righe.map((r) => `
    <button class="row" data-prodotto="${r.prodotto_id}">
      <span class="avatar">${cat(r.categoria)[0]}</span>
      <span class="row-main"><span class="row-name">${esc(r.nome)}</span>
        <span class="row-sub num">costo ${fmt(r.prezzo_acquisto_ivato)}</span></span>
      ${pill(r.variazione, r.prezzo_precedente == null)}
      ${cartellino(r.prezzo_vendita, r.unita)}
    </button>`).join("");
  $("#doc-elimina").addEventListener("click", async () => {
    if (!confirm("Annullare questa fattura? I suoi prezzi verranno tolti dallo storico.")) return;
    await api(`/api/documenti/${d.id}`, { method: "DELETE" });
    chiudiSheet();
    toast("Fattura annullata");
    ricarica();
  });
}

/* ------------------------------------------------------------------ grafico (SVG) */
let gradN = 0;
function disegnaGrafico(el, pts, unita) {
  const W = Math.max(el.clientWidth || 320, 260), H = 200, L = 46, R = 16, T = 36, B = 26;
  const ya = pts.map((p) => p.prezzo_acquisto_ivato);
  let lo = Math.min(...ya), hi = Math.max(...ya);
  const pad = (hi - lo) * 0.3 || hi * 0.15 || 1;
  lo = Math.max(0, lo - pad); hi += pad;
  const n = pts.length;
  const X = (i) => (n === 1 ? (L + W - R) / 2 : L + (i * (W - L - R)) / (n - 1));
  const Y = (v) => T + ((hi - v) / (hi - lo)) * (H - T - B);
  const id = `g${++gradN}`;
  let griglia = "";
  for (let k = 0; k <= 2; k++) {
    const v = lo + ((hi - lo) * k) / 2, y = Y(v);
    griglia += `<line class="grid" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/><text class="axis" x="${L - 8}" y="${y + 4}" text-anchor="end">${v.toFixed(2).replace(".", ",")}</text>`;
  }
  const passo = Math.max(1, Math.ceil(n / 4));
  let etichette = "";
  pts.forEach((p, i) => {
    if (i % passo === 0 || i === n - 1) etichette += `<text class="axis" x="${X(i)}" y="${H - 6}" text-anchor="${i === 0 && n > 1 ? "start" : i === n - 1 && n > 1 ? "end" : "middle"}">${dataIt(p.data_acquisizione, false)}</text>`;
  });
  const linea = pts.map((p, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(p.prezzo_acquisto_ivato).toFixed(1)}`).join(" ");
  const area = n > 1 ? `${linea} L${X(n - 1)},${H - B} L${X(0)},${H - B} Z` : "";
  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Andamento del costo d'acquisto">
      <defs><linearGradient id="${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#8fdcff" stop-opacity=".32"/><stop offset="1" stop-color="#8fdcff" stop-opacity="0"/></linearGradient></defs>
      ${griglia}${etichette}
      ${area ? `<path d="${area}" fill="url(#${id})"/>` : ""}
      <path d="${linea}" fill="none" stroke="#8fdcff" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/>
      <line class="cursor" y1="${T - 4}" y2="${H - B}" stroke="#8fdcff" stroke-width="1" opacity="0"/>
      ${pts.map((p, i) => `<circle cx="${X(i)}" cy="${Y(p.prezzo_acquisto_ivato)}" r="${i === n - 1 ? 5.5 : 3.5}" fill="${i === n - 1 ? "#8fdcff" : "#132650"}" stroke="#8fdcff" stroke-width="2"/>`).join("")}
    </svg>
    <div class="chart-tip num"></div>
    ${n === 1 ? '<p class="chart-note">Una sola fornitura finora. L\'andamento si vedrà dalla prossima fattura.</p>' : ""}`;
  const svg = $("svg", el), tip = $(".chart-tip", el), cursore = $(".cursor", el);
  const mostra = (i) => {
    const p = pts[i], scala = svg.getBoundingClientRect().width / W;
    tip.textContent = `${dataIt(p.data_acquisizione)}  ${fmt(p.prezzo_acquisto_ivato)}/${unita}`;
    const x = X(i) * scala, w = tip.offsetWidth;
    tip.style.left = `${Math.min(Math.max(x, w / 2), el.clientWidth - w / 2)}px`;
    cursore.setAttribute("x1", X(i)); cursore.setAttribute("x2", X(i)); cursore.setAttribute("opacity", ".5");
  };
  const vicino = (ev) => {
    const r = svg.getBoundingClientRect(), x = ((ev.clientX - r.left) / r.width) * W;
    let best = 0;
    pts.forEach((_, i) => { if (Math.abs(X(i) - x) < Math.abs(X(best) - x)) best = i; });
    return best;
  };
  svg.addEventListener("pointermove", (ev) => mostra(vicino(ev)));
  svg.addEventListener("pointerdown", (ev) => mostra(vicino(ev)));
  requestAnimationFrame(() => mostra(n - 1));
}

/* ------------------------------------------------------------------ pannello dal basso */
let sheetBloccato = false;
function apriSheet(html, { full = false, bloccato = false } = {}) {
  $("#sheet-body").innerHTML = html;
  $("#sheet").classList.toggle("full", full);
  $("#sheet").hidden = false;
  $("#backdrop").hidden = false;
  $("#sheet").scrollTop = 0;
  sheetBloccato = bloccato;
  document.body.style.overflow = "hidden";
}
function chiudiSheet() {
  $("#sheet").hidden = true;
  $("#backdrop").hidden = true;
  document.body.style.overflow = "";
  state.rev = null;
}
$("#backdrop").addEventListener("click", () => { if (!sheetBloccato) chiudiSheet(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !sheetBloccato && !$("#sheet").hidden) chiudiSheet(); });
const icona = {
  x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  matita: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16Z"/><path d="m13.5 6.5 4 4"/></svg>',
};
const bottoneChiudi = `<button class="round" data-chiudi aria-label="Chiudi">${icona.x}</button>`;

/* ------------------------------------------------------------------ dettaglio prodotto */
async function apriDettaglio(p) {
  if (!p) return;
  const margine = p.prezzo_vendita - p.prezzo_acquisto_ivato;
  apriSheet(`
    <div class="sheet-head">
      <div><h3>${esc(p.nome)}</h3><p>${cat(p.categoria)[0]} ${cat(p.categoria)[1]}, ${plurale(p.n_acquisti, "fornitura", "forniture")}</p></div>
      <div class="head-actions"><button class="round" id="det-modifica" aria-label="Modifica prodotto">${icona.matita}</button>${bottoneChiudi}</div>
    </div>
    <div class="hero">
      <div class="shelf"><div class="shelf-name">Prezzo al pubblico</div>
        <div class="shelf-price">${prezzoGrande(p.prezzo_vendita)}</div>
        <div class="shelf-foot"><span>€ al ${p.unita}</span></div></div>
      <div class="facts">
        <div class="fact"><span>Costo ivato</span><b>${fmt(p.prezzo_acquisto_ivato)}</b> ${p.n_acquisti > 1 ? pill(p.variazione_ultima) : ""}</div>
        <div class="fact"><span>Guadagno al ${p.unita}</span><b>${fmt(margine)}</b></div>
      </div>
    </div>
    <div class="chart-box"><div class="chart" id="chart-det"></div></div>
    <table class="hist"><thead><tr><th>Data</th><th>Fornitore</th><th class="r">Costo</th><th class="r">Differenza</th></tr></thead>
      <tbody id="hist-body"></tbody></table>
    <button class="btn btn-danger btn-block" id="det-elimina" style="margin-top:18px">Elimina prodotto e storico</button>`);

  const storico = await api(`/api/prodotti/${p.id}/storico`);
  disegnaGrafico($("#chart-det"), storico, p.unita);
  $("#hist-body").innerHTML = [...storico].reverse().map((s) => `
    <tr><td>${dataIt(s.data_acquisizione)}${s.descrizione_originale ? `<div class="desc">${esc(s.descrizione_originale)}</div>` : ""}</td>
      <td>${esc(s.fornitore || "—")}</td><td class="r">${fmt(s.prezzo_acquisto_ivato)}</td>
      <td class="r">${s.variazione == null ? "—" : pill(s.variazione)}</td></tr>`).join("");

  $("#det-modifica").addEventListener("click", () => apriModifica(p));
  $("#det-elimina").addEventListener("click", async () => {
    if (!confirm(`Eliminare "${p.nome}" con tutto il suo storico? Non si può annullare.`)) return;
    await api(`/api/prodotti/${p.id}`, { method: "DELETE" });
    chiudiSheet();
    toast(`${p.nome} eliminato`);
    ricarica();
  });
}

function apriModifica(p) {
  let unita = p.unita;
  apriSheet(`
    <div class="sheet-head"><div><h3>Modifica prodotto</h3></div>${bottoneChiudi}</div>
    <label class="field"><span>Nome</span><input class="input" id="m-nome" value="${esc(p.nome)}" maxlength="80"></label>
    <p class="hint">Se scrivi il nome di un prodotto che esiste già, i due vengono uniti in uno solo con tutto lo storico.</p>
    <label class="field"><span>Categoria</span><select class="select" id="m-cat">${opzioniCategoria(p.categoria)}</select></label>
    <div class="field"><span>Si vende</span>
      <div class="seg" id="m-unita"><button data-u="pz" class="${unita === "pz" ? "on" : ""}">Al pezzo</button><button data-u="kg" class="${unita === "kg" ? "on" : ""}">Al chilo</button></div></div>
    <button class="btn btn-primary btn-block" id="m-salva">Salva modifiche</button>`);
  $$("#m-unita button").forEach((b) => b.addEventListener("click", () => {
    unita = b.dataset.u;
    $$("#m-unita button").forEach((x) => x.classList.toggle("on", x === b));
  }));
  $("#m-salva").addEventListener("click", async () => {
    const nome = $("#m-nome").value.trim();
    if (!nome) return toast("Scrivi un nome", "ko");
    const esiste = state.prodotti.find((x) => x.id !== p.id && x.nome.toLowerCase() === nome.toLowerCase());
    if (esiste && !confirm(`"${esiste.nome}" esiste già. Unire i due prodotti?`)) return;
    try {
      const r = await api(`/api/prodotti/${p.id}`, { method: "PATCH", body: JSON.stringify({ nome, unita, categoria: $("#m-cat").value }) });
      await ricarica();
      toast(r.unito ? "Prodotti uniti" : "Modifiche salvate");
      apriDettaglio(state.prodotti.find((x) => x.id === r.id));
    } catch (e) { toast(e.message, "ko", 6000); }
  });
}

/* ------------------------------------------------------------------ nuova fattura */
function apriNuova() {
  state.pagine.forEach((p) => URL.revokeObjectURL(p.url));
  state.pagine = [];
  renderNuova();
}
$("#fab").addEventListener("click", apriNuova);

function renderNuova() {
  const n = state.pagine.length;
  const camera = '<svg viewBox="0 0 24 24"><path d="M4 8.5a2 2 0 0 1 2-2h1.6l1.2-1.8a2 2 0 0 1 1.7-.9h3a2 2 0 0 1 1.7.9l1.2 1.8H18a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"/><circle cx="12" cy="13" r="3.4"/></svg>';
  apriSheet(n ? `
    <div class="sheet-head"><div><h3>${plurale(n, "pagina", "pagine")}</h3><p>Se la fattura continua su altri fogli, aggiungili prima di leggerla.</p></div>${bottoneChiudi}</div>
    <div class="pages">
      ${state.pagine.map((p, i) => `<div class="page"><img src="${p.url}" alt="Pagina ${i + 1}"><span>${i + 1}</span><button data-togli="${i}" aria-label="Togli pagina ${i + 1}">✕</button></div>`).join("")}
      ${n < 6 ? '<button class="page add" data-scatta>+ Aggiungi pagina</button>' : ""}
    </div>
    <button class="btn btn-primary btn-block" id="leggi">Leggi la fattura</button>` : `
    <div class="sheet-head"><div><h3>Nuova fattura</h3><p>Inquadra tutta la pagina, dritta e ben illuminata.</p></div>${bottoneChiudi}</div>
    <button class="choice main" data-scatta>${camera}<div><b>Scatta una foto</b><span>Fattura o bolla di consegna</span></div></button>
    <button class="choice" data-galleria><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/></svg><div><b>Scegli dalla galleria</b><span>Anche più pagine insieme</span></div></button>
    <button class="choice" data-manuale>${icona.matita}<div><b>Scrivi a mano</b><span>Per acquisti senza fattura</span></div></button>`);
}
$("#sheet").addEventListener("click", (e) => {
  if (e.target.closest("[data-scatta]")) $("#foto-camera").click();
  else if (e.target.closest("[data-galleria]")) $("#foto-galleria").click();
  else if (e.target.closest("[data-manuale]")) apriRevisione({ prodotti: [{}] }, true);
  else if (e.target.closest("[data-togli]")) {
    const [tolta] = state.pagine.splice(+e.target.closest("[data-togli]").dataset.togli, 1);
    URL.revokeObjectURL(tolta.url);
    renderNuova();
  } else if (e.target.closest("#leggi")) leggiFattura();
});
["#foto-camera", "#foto-galleria"].forEach((s) => $(s).addEventListener("change", (e) => {
  for (const f of [...e.target.files].slice(0, 6 - state.pagine.length)) state.pagine.push({ file: f, url: URL.createObjectURL(f) });
  e.target.value = "";
  if (state.pagine.length) renderNuova();
}));

async function riduciFoto(file) {
  /* ridimensiona sul telefono (max 2000px): l'invio sul Wi‑Fi diventa molto più veloce */
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const k = Math.min(1, 2000 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    return await new Promise((ok) => c.toBlob((b) => ok(b || file), "image/jpeg", 0.88));
  } catch {
    return file;
  }
}

async function leggiFattura() {
  const pagine = state.pagine;
  if (!pagine.length) return;
  $("#scan-img").src = pagine[0].url;
  $("#scan").hidden = false;
  const sub = $("#scan-sub");
  sub.textContent = "Di solito bastano 10–20 secondi";
  const lento = setTimeout(() => (sub.textContent = "Gemini è lento in questo momento. Resta su questa pagina, ci sto ancora lavorando."), 25000);
  try {
    const fd = new FormData();
    for (const p of pagine) fd.append("foto", await riduciFoto(p.file), "pagina.jpg");
    const r = await api("/api/fattura/analizza", { method: "POST", body: fd });
    if (!r.prodotti.length) return toast("Non ho trovato prodotti. Riprova con una foto più nitida e dritta.", "ko", 6500);
    apriRevisione(r);
  } catch (e) {
    toast(e.message, "ko", 8000);
  } finally {
    clearTimeout(lento);
    $("#scan").hidden = true;
  }
}

/* ------------------------------------------------------------------ controllo e salvataggio */
const esistente = (nome) => state.prodotti.find((x) => x.nome.toLowerCase() === String(nome || "").trim().toLowerCase());

function apriRevisione(r, manuale = false) {
  state.rev = {
    fornitore: r.fornitore || "", numero: r.numero_documento || "",
    data: /^\d{4}-\d{2}-\d{2}$/.test(r.data_documento || "") ? r.data_documento : oggiIso(),
    righe: r.prodotti.map((p) => ({
      on: true, nome: p.nome_pulito || "", unita: p.unita || "pz", categoria: p.categoria || "altro",
      prezzo: p.prezzo_unitario_ivato != null ? (Math.round(p.prezzo_unitario_ivato * 100) / 100).toFixed(2).replace(".", ",") : "",
      warn: !!p.da_verificare, desc: p.descrizione_originale || "",
    })),
  };
  apriSheet(`
    <div class="sheet-head">
      <div><h3>${manuale ? "Acquisto a mano" : "Controlla i prezzi"}</h3>
        <p>${manuale ? "Scrivi il costo di un pezzo o di un chilo, IVA inclusa." : `Ho letto ${plurale(r.prodotti.length, "prodotto", "prodotti")}. Correggi quello che non torna, poi salva.`}</p></div>
      <button class="round" id="rev-annulla" aria-label="Annulla">${icona.x}</button>
    </div>
    <div class="grid2">
      <label class="field"><span>Fornitore</span><input class="input" id="rev-fornitore" value="${esc(state.rev.fornitore)}"></label>
      <label class="field"><span>Numero</span><input class="input" id="rev-numero" value="${esc(state.rev.numero)}"></label>
    </div>
    <label class="field"><span>Data della fornitura</span><input class="input" type="date" id="rev-data" value="${state.rev.data}"></label>
    <div id="rev-items"></div>
    <button class="btn btn-ghost btn-block" id="rev-aggiungi">Aggiungi un prodotto</button>
    <div class="sticky-foot"><button class="btn btn-primary btn-block" id="rev-salva">Salva</button></div>`, { full: true, bloccato: true });

  renderRighe();
  $("#rev-annulla").addEventListener("click", () => {
    if (confirm("Chiudere senza salvare?")) chiudiSheet();
  });
  $("#rev-aggiungi").addEventListener("click", () => {
    state.rev.righe.push({ on: true, nome: "", unita: "pz", categoria: "altro", prezzo: "", warn: false, desc: "" });
    renderRighe();
    $$("#rev-items .item").at(-1).querySelector("[data-k=nome]").focus();
  });
  $("#rev-fornitore").addEventListener("input", (e) => (state.rev.fornitore = e.target.value));
  $("#rev-numero").addEventListener("input", (e) => (state.rev.numero = e.target.value));
  $("#rev-data").addEventListener("input", (e) => (state.rev.data = e.target.value));
  $("#rev-salva").addEventListener("click", salvaRevisione);

  const box = $("#rev-items");
  const aggiorna = (e) => {
    const i = e.target.closest(".item")?.dataset.i, k = e.target.dataset.k;
    if (i == null || !k) return;
    state.rev.righe[i][k] = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    if (k === "on") e.target.closest(".item").classList.toggle("off", !e.target.checked);
    aggiornaCalcolo(i);
  };
  box.addEventListener("input", aggiorna);
  box.addEventListener("change", aggiorna);
  box.addEventListener("click", (e) => {
    const u = e.target.closest("[data-unita]");
    if (!u) return;
    const item = u.closest(".item");
    state.rev.righe[item.dataset.i].unita = u.dataset.unita;
    $$("[data-unita]", item).forEach((b) => b.classList.toggle("on", b === u));
    aggiornaCalcolo(item.dataset.i);
  });
}

function renderRighe() {
  $("#rev-items").innerHTML = state.rev.righe.map((r, i) => `
    <div class="item ${r.on ? "" : "off"} ${r.warn ? "warn" : ""}" data-i="${i}">
      <div class="item-top">
        <label class="switch"><input type="checkbox" data-k="on" ${r.on ? "checked" : ""} aria-label="Salva questo prodotto"><span></span></label>
        <input class="input" data-k="nome" value="${esc(r.nome)}" placeholder="Nome, per esempio Orata" maxlength="80" aria-label="Nome del prodotto">
      </div>
      <div class="item-mid">
        <div class="eur"><input class="input" data-k="prezzo" inputmode="decimal" value="${esc(r.prezzo)}" placeholder="Costo" aria-label="Costo ivato"></div>
        <div class="unit"><button data-unita="pz" class="${r.unita === "pz" ? "on" : ""}">pezzo</button><button data-unita="kg" class="${r.unita === "kg" ? "on" : ""}">kg</button></div>
        <select class="select" data-k="categoria" aria-label="Categoria">${opzioniCategoria(r.categoria)}</select>
      </div>
      <div class="item-calc" data-calc></div>
      ${r.warn ? '<div class="warn-tag">I conti della riga non tornavano e ho ricalcolato il costo: confrontalo con la fattura.</div>' : ""}
      ${r.desc ? `<div class="item-desc">In fattura: ${esc(r.desc)}</div>` : ""}
    </div>`).join("");
  state.rev.righe.forEach((_, i) => aggiornaCalcolo(i));
  if (!state.rev.righe.length) aggiornaSalva();
}

function aggiornaSalva() {
  const valide = state.rev.righe.filter((x) => x.on && x.nome.trim() && num(x.prezzo) > 0).length;
  const btn = $("#rev-salva");
  btn.textContent = valide ? `Salva ${plurale(valide, "prodotto", "prodotti")}` : "Salva";
  btn.disabled = !valide;
}
function aggiornaCalcolo(i) {
  const r = state.rev.righe[i], el = $(`#rev-items .item[data-i="${i}"] [data-calc]`);
  if (!el) return;
  const p = num(r.prezzo), prima = esistente(r.nome);
  const sinistra = !r.nome.trim() ? "" : !prima ? '<span class="pill new">nuovo prodotto</span>'
    : `<span>Prima ${fmt(prima.prezzo_acquisto_ivato)} ${p ? pill(Math.round((p - prima.prezzo_acquisto_ivato) * 100) / 100) : ""}</span>`;
  el.innerHTML = `<span>${sinistra}</span>${p ? cartellino(vendita(p), r.unita) : ""}`;
  aggiornaSalva();
}

async function salvaRevisione() {
  const rv = state.rev;
  const righe = rv.righe.filter((r) => r.on && r.nome.trim() && num(r.prezzo) > 0)
    .map((r) => ({ nome: r.nome.trim(), unita: r.unita, categoria: r.categoria, prezzo: num(r.prezzo), descrizione: r.desc || null }));
  const btn = $("#rev-salva");
  btn.disabled = true;
  btn.textContent = "Salvo…";
  try {
    const r = await api("/api/acquisti", { method: "POST", body: JSON.stringify({ fornitore: rv.fornitore, numero_documento: rv.numero, data: rv.data, righe }) });
    await ricarica();
    mostraEsiti(r.esiti);
  } catch (e) {
    toast(e.message, "ko", 6000);
    aggiornaSalva();
  }
}

function mostraEsiti(esiti) {
  const su = esiti.filter((e) => e.variazione > 0.005).length, giu = esiti.filter((e) => e.variazione < -0.005).length;
  const daFare = state.prodotti.filter((p) => p.cartellino).length;
  const riepilogo = [su && plurale(su, "rincaro", "rincari"), giu && plurale(giu, "ribasso", "ribassi")].filter(Boolean).join(" e ") || "Nessuna variazione di costo";
  apriSheet(`
    <div class="sheet-head"><div><h3>Fattura salvata</h3><p>${riepilogo}</p></div>${bottoneChiudi}</div>
    <div class="panel list">
      ${esiti.map((e) => `<div class="row"><span class="avatar">${cat(e.categoria)[0]}</span>
          <span class="row-main"><span class="row-name">${esc(e.nome)}</span>
            <span class="row-sub num">${e.prezzo_precedente == null ? `costo ${fmt(e.prezzo_acquisto)}` : `${fmt(e.prezzo_precedente)} → ${fmt(e.prezzo_acquisto)}`}</span></span>
          ${pill(e.variazione, e.prezzo_precedente == null)}${cartellino(e.prezzo_vendita, e.unita)}</div>`).join("")}
    </div>
    <button class="btn btn-primary btn-block" id="esiti-ok" style="margin-top:16px">${daFare ? `Vai ai ${plurale(daFare, "cartellino", "cartellini")} da riscrivere` : "Fatto"}</button>`);
  $("#esiti-ok").addEventListener("click", () => { chiudiSheet(); vai("oggi"); });
}

/* ------------------------------------------------------------------ ALTRO (impostazioni e strumenti) */
async function renderAltro() {
  const c = await api("/api/impostazioni");
  let provider = c.ai_provider, arrotonda = c.arrotonda;
  const statoAi = c.ai_provider === "ollama" ? ["", "Ollama sul PC, senza Internet"]
    : c.chiave_impostata ? ["ok", `Chiave salvata (finisce con ${esc(c.chiave_finale)})`] : ["ko", "Chiave non ancora inserita"];
  $("#altro").innerHTML = `
    <div class="group"><h3>Prezzi</h3>
      <label class="field"><span>Ricarico sul costo ivato, in percentuale</span>
        <input class="input" id="s-ricarico" inputmode="decimal" value="${String(c.ricarico).replace(".", ",")}"></label>
      <div class="field"><span>Arrotonda il prezzo al pubblico</span>
        <div class="seg" id="s-arrotonda">
          <button data-a="0.01" class="${arrotonda === "0.01" ? "on" : ""}">Al centesimo</button>
          <button data-a="0.05" class="${arrotonda === "0.05" ? "on" : ""}">Ai 5 cent</button>
          <button data-a="0.10" class="${arrotonda === "0.10" ? "on" : ""}">Ai 10 cent</button>
        </div></div>
      <p class="hint" id="s-esempio"></p>
      <button class="btn btn-primary btn-block" id="s-salva-prezzi">Salva i prezzi</button>
    </div>

    <div class="group"><h3>Lettura delle fatture</h3>
      <div class="seg" id="s-provider">
        <button data-p="gemini" class="${provider === "gemini" ? "on" : ""}">Google Gemini</button>
        <button data-p="ollama" class="${provider === "ollama" ? "on" : ""}">Ollama, senza Internet</button>
      </div>
      <div class="status ${statoAi[0]}" id="s-stato"><i></i><span>${statoAi[1]}</span></div>
      <div id="s-gemini" ${provider === "gemini" ? "" : "hidden"}>
        <label class="field"><span>Chiave Gemini</span>
          <input class="input" id="s-chiave" type="password" autocomplete="off" placeholder="${c.chiave_impostata ? "Lascia vuoto per tenerla" : "Incolla qui la chiave"}"></label>
        <p class="hint">È gratuita: creala su <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a>. Il modello viene scelto da solo tra quelli gratuiti che rispondono.</p>
      </div>
      <div id="s-ollama" ${provider === "ollama" ? "" : "hidden"}>
        <label class="field"><span>Indirizzo di Ollama</span><input class="input" id="s-ourl" value="${esc(c.ollama_url)}"></label>
        <label class="field"><span>Modello</span><input class="input" id="s-omodel" value="${esc(c.ollama_model)}"></label>
      </div>
      <button class="btn btn-primary btn-block" id="s-prova">Salva e prova</button>
    </div>

    <div class="group"><h3>Listino e copie</h3>
      <button class="btn btn-ghost btn-block" id="s-stampa">Stampa il listino prezzi</button>
      <a class="btn btn-ghost" href="/api/export/listino.csv" download>Scarica il listino per Excel</a>
      <a class="btn btn-ghost" href="/api/export/backup.db" download>Scarica una copia di sicurezza</a>
    </div>

    <div class="group"><h3>Negozio e accesso</h3>
      <label class="field"><span>Nome del negozio</span><input class="input" id="s-nome" value="${esc(c.nome_negozio)}" maxlength="60"></label>
      <label class="field"><span>${c.pin_impostato ? "Nuovo PIN (lascia vuoto per tenerlo)" : "PIN per entrare (facoltativo)"}</span>
        <input class="input" id="s-pin" inputmode="numeric" type="password" autocomplete="new-password"></label>
      ${c.pin_impostato ? '<button class="btn btn-ghost btn-block" id="s-nopin">Togli il PIN</button>' : ""}
      <button class="btn btn-primary btn-block" id="s-salva-negozio">Salva</button>
    </div>

    <div class="group"><h3>Usala dal telefono</h3>
      <div style="display:flex;gap:14px;align-items:center;margin-bottom:14px">
        <img src="/api/qr.svg" class="qr" alt="Codice QR">
        <div><p class="muted">Con il telefono sullo stesso Wi‑Fi del PC, inquadra il codice o apri</p><p class="url">${esc(c.url_telefono)}</p></div>
      </div>
      <p class="hint">Dal menu del browser scegli “Aggiungi a schermata Home” per avere l'icona come un'app.</p>
    </div>`;

  const esempio = () => {
    const ric = num($("#s-ricarico").value) ?? 0, passo = parseFloat(arrotonda);
    const v = Math.round(Math.round((4.37 * (1 + ric / 100)) / passo + 1e-7) * passo * 100) / 100;
    $("#s-esempio").textContent = `Esempio: un costo di 4,37 € diventa ${fmt(v)} al pubblico.`;
  };
  esempio();
  $("#s-ricarico").addEventListener("input", esempio);
  const segmento = (sel, attr, fn) => $$(`${sel} button`).forEach((b) => b.addEventListener("click", () => {
    $$(`${sel} button`).forEach((x) => x.classList.toggle("on", x === b));
    fn(b.dataset[attr]);
  }));
  segmento("#s-arrotonda", "a", (v) => { arrotonda = v; esempio(); });
  segmento("#s-provider", "p", (v) => {
    provider = v;
    $("#s-gemini").hidden = v !== "gemini";
    $("#s-ollama").hidden = v !== "ollama";
  });

  const salva = async (dati, messaggio) => {
    try {
      const n = await api("/api/impostazioni", { method: "POST", body: JSON.stringify(dati) });
      $("#nome-negozio").textContent = n.nome_negozio;
      document.title = n.nome_negozio;
      await ricarica();
      if (messaggio) toast(messaggio);
      return true;
    } catch (e) { toast(e.message, "ko", 6000); return false; }
  };
  $("#s-salva-prezzi").addEventListener("click", () => {
    const ric = num($("#s-ricarico").value);
    if (ric == null || ric < 0) return toast("Scrivi un ricarico valido, per esempio 40", "ko");
    salva({ ricarico: ric, arrotonda }, "Prezzi aggiornati");
  });
  $("#s-salva-negozio").addEventListener("click", async () => {
    const dati = { nome_negozio: $("#s-nome").value.trim() || "Il mio negozio" };
    if ($("#s-pin").value.trim()) dati.pin = $("#s-pin").value.trim();
    if (await salva(dati, "Salvato")) renderAltro();
  });
  $("#s-nopin")?.addEventListener("click", async () => { if (await salva({ pin: "" }, "PIN tolto")) renderAltro(); });
  $("#s-prova").addEventListener("click", async (ev) => {
    const b = ev.currentTarget, dati = { ai_provider: provider, ollama_url: $("#s-ourl").value.trim(), ollama_model: $("#s-omodel").value.trim() };
    if ($("#s-chiave").value.trim()) dati.gemini_api_key = $("#s-chiave").value.trim();
    b.disabled = true; b.textContent = "Provo il collegamento…";
    const st = $("#s-stato");
    if (await salva(dati)) {
      try {
        const r = await api("/api/impostazioni/prova-ai", { method: "POST" });
        st.className = "status ok"; st.lastElementChild.textContent = r.messaggio;
        $("#s-chiave").value = "";
      } catch (e) {
        st.className = "status ko"; st.lastElementChild.textContent = e.message;
      }
    }
    b.disabled = false; b.textContent = "Salva e prova";
  });
  $("#s-stampa").addEventListener("click", stampaListino);
}

function stampaListino() {
  if (!state.prodotti.length) return toast("Non ci sono ancora prodotti da stampare", "ko");
  const gruppi = Object.keys(CATEGORIE).map((k) => [k, state.prodotti.filter((p) => p.categoria === k).sort((a, b) => a.nome.localeCompare(b.nome, "it"))]).filter(([, l]) => l.length);
  $("#stampa").innerHTML = `<h1>${esc($("#nome-negozio").textContent)}</h1><p>Listino prezzi del ${new Date().toLocaleDateString("it-IT")}</p>` +
    gruppi.map(([k, l]) => `<h2>${cat(k)[1]}</h2><table>${l.map((p) => `<tr><td>${esc(p.nome)}</td><td>${fmt(p.prezzo_vendita)} / ${p.unita}</td></tr>`).join("")}</table>`).join("");
  window.print();
}

avvio();
